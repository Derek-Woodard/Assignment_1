%%
% Derek Woodard, 100827083

%% Part 1: Electron Modeling
% To calculate thermal velocity, we are given that temperature T = 300K
% It should be noted that there are only two degrees of freedom
% Each electron is able to move in the x and y direction


clear all
close all
m0 = 9.10938356e-31;          % rest mass of an electron
mn = 0.26*m0;                 % effective mass of electrons
T = 300;                      % temperature
k = 1.38064852e-23;           % Boltzmann's Constant
Tmn = 0.2e-12;                % mean time between collisions
vth = sqrt((2*k*T)/mn);       % calculate thermal velocity for 1.1 with two degrees of freedom

% vth is 1.87e+5 m/s or 187 km/s

%% Mean free path
% We are given that the time between collisions is Tmn = 0.2ps

mfp = vth * Tmn;              % calculate the mean free path for 1.2

% mfp is 37.4nm

%% The nominal size of the region is 200nm x 100nm
% The random motion of the elctrons in this region are to be modeled
% This is done using a simplistic Monte Carlo model 

H = 100e-9;
W = 200e-9;
pop_tot = 5000;         % use this variable to determine how many electrons are modeled
pop_vis = 15;           % use this variable to change how many electrons are plotted
ts = H/vth/100;         % The time step is set to make each plot point have an electron move 1/100th of the height of the area
iter = 1000;            % how many plot points total
% animate = 1;            % set to 1 to see each iteration
animate = 0;            % set to 0 to only see final product
                        
%%
% In order to track the electrons, the following arrays will be used
% The arrays will store the positions, velocities, and temperatures of the
% elctrons
state = zeros(pop_tot, 4);
% The rows of state represent each electron
% The columns represent the position and velocity in each direction as shown
% [x y vx vy]

traj = zeros(iter, pop_vis*2);
% The trajectory of the electrons we want to plot will be stored here

temps = zeros(iter,1);
% The temperature will be tracked in this array

%% 
% Start by generating the initial eletrons with a constant speed of vth
for i = 1:pop_tot
    angle = rand*2*pi;
    state(i,:) = [W*rand H*rand vth*cos(angle) vth*sin(angle)];
end


%%
% Now we iterate to update the electron positions and plot the trajectories
for i = 1:iter
    state(:,1:2) = state(:,1:2) + ts.*state(:,3:4);
    % update the state of each electron using the speed
    
    % We need to ensure the boundary conditions are checked
    bcx = state(:,1) > W;
    state(bcx,1) = state(bcx,1) - W;
    % Ensure the electron is transported from the right side to the left if
    % travelling past the right X limit
    
    bcx = state(:,1) < 0;
    state(bcx,1) = state(bcx,1) + W;
    % Ensure the electron is transported from the left side to the right if
    % travelling past the left X limit
    
    bcy = state(:,2) > H;
    state(bcy,2) = 2*H - state(bcy,2);
    state(bcy,4) = -state(bcy,4);
    % Ensure the electrons bounce back down if going above high the Y limit
    
    bcy = state(:,2) < 0;
    state(bcy,2) = -state(bcy,2);
    state(bcy,4) =- state(bcy,4);
    % Ensure the electrons bounce back up if going below the low Y limit
    
    temps(i) = (sum(state(:,3).^2) + sum(state(:,4).^2)) * mn/k/2/pop_tot;
    % Track the temperature using the velocity of every electron at every
    % point
    
    for j = 1:pop_vis
        traj(i, (2*j):(2*j+1)) = state(j, 1:2);
    end
    % Track the trajectory of a small number of electrons by storing the x
    % and y position for each iteration
    
    % The animation does not need to be updated at every iteration
    % So we update it every 5 iterations to use less memory
    if animate && mod(i,5) == 0
        figure(1)
        pbaspect([2,1,1]);
        subplot(2,1,1);
        hold off;
        plot(state(1:pop_vis,1)./1e-9, state(1:pop_vis,2)./1e-9, 'o');
        axis([0 W/1e-9 0 H/1e-9]);
        title(sprintf('Trajectories for %d of %d Electrons with a Fixed Velocity (P.1)', pop_vis, pop_tot));
        xlabel('X (nm)');
        ylabel('Y (nm)');
        hold on;
        for j=1:pop_vis
            plot(traj(:,j*2)./1e-9, traj(:,j*2+1)./1e-9, '.');
        end
        
        if i > 1
            subplot(2,1,2);
            hold off;
            plot(ts*(0:i-1), temps(1:i));
            axis([0 ts*iter min(temps)*0.98 max(temps)*1.02]);
            title('Temperature of the Semi-Conductor');
            xlabel('Time (s)');
            ylabel('Temperature (K)');
        end
        pause(0.05)
    end
end

% Now we need to display the trajectory after the iterations of completed
figure(1);
pbaspect([2,1,1]);
subplot(2,1,1);
title(sprintf('Trajectories for %d of %d Electrons with a Fixed Velocity (P.1)', pop_vis, pop_tot));
xlabel('X (nm)');
ylabel('Y (nm)');
axis([0 W/1e-9 0 H/1e-9]);
hold on;
for i=1:pop_vis
    plot(traj(:,i*2)./1e-9, traj(:,i*2+1)./1e-9, '.');
end

% If the animation variable = 0, we need to simply plot the results
if(~animate)
    subplot(2,1,2);
    hold off;
    plot(ts*(0:pop_vis-1), temps(1:pop_vis));
    axis([0 ts*iter min(temps)*0.98 max(temps)*1.02]);
    title('Temperature of the Semi-Conductor');
    xlabel('Time (s)');
    ylabel('Temperature (K)');
end


%% Part 2: Collisions with Mean Free Path (MFP)
    
%%
% In order to track the electrons, the following arrays will be used
% The arrays will store the positions, velocities, and temperatures of the
% elctrons
% note that these are made the same way as in part 1
state2 = zeros(pop_tot, 4);
% The rows of state represent each electron
% The columns represent the position and velocity in each direction as shown
% [x y vx vy]

traj2 = zeros(iter, pop_vis*2);
% The trajectory of the electrons we want to plot will be stored here

temps2 = zeros(iter,1);
avgtemps2 = zeros(iter,1);
% The average temperature will abe tracked as well as the temperature of
% each electron

initvels = zeros(pop_tot,1);
% The initially set velocities of all atoms are stored here to be tracked on
% a histogram

mfps = zeros(pop_tot,1);
meanfp = 0;
% To measure the mean free path, an array is used to track how far each
% electron has travelled before scattering

tbc = zeros(pop_tot,1);
meantbc = 0;
% The measured time between collisions will be tracked through an array

% animate2 = 1;               % set to 1 to see each iteration 
animate2 = 0;               % set to 0 to only see the final product

%% 
% Start by generating the initial eletrons with a normally distributed
% speed averaging around vth
for i = 1:pop_tot
    angle = rand*2*pi;
    vel = randn*vth;
    initvels(i) = vel;
    state2(i,:) = [W*rand H*rand vel*cos(angle) vel*sin(angle)];
end

%%
% The average value of the initial values should be around vth
vavg = sqrt(sum(state2(:,3).^2)/pop_tot + sum(state2(:,4).^2)/pop_tot);


%%
% We track the distribution of the speeds using a histogram
figure(2)
pbaspect([2,1,1]);
subplot(3,1,3);
histogram(initvels)
title(sprintf('Initial Assigned Velocities with Average %d', vavg));
xlabel('velocity (m/s)');
ylabel('electrons');


%%
% Each electron will have a scattering probability which will change the
% direction and speed of it.
% The electrons have an exponential scattering probability based on the
% time-step and the mean time between collisions
ps = 1 - exp(-((ts)/(Tmn)));

%%
% Now we iterate to update the electron positions and plot the trajectories
for i = 1:iter
    
    state2(:,1:2) = state2(:,1:2) + ts.*state2(:,3:4);
    % update the state of each electron using the speed
    
    % We need to ensure the boundary conditions are checked
    bcx = state2(:,1) > W;
    state2(bcx,1) = state2(bcx,1) - W;
    % Ensure the electron is transported from the right side to the left if
    % travelling past the right X limit
    
    bcx = state2(:,1) < 0;
    state2(bcx,1) = state2(bcx,1) + W;
    % Ensure the electron is transported from the left side to the right if
    % travelling past the left X limit
    
    bcy = state2(:,2) > H;
    state2(bcy,2) = 2*H - state2(bcy,2);
    state2(bcy,4) = -state2(bcy,4);
    % Ensure the electrons bounce back down if going above high the Y limit
    
    bcy = state2(:,2) < 0;
    state2(bcy,2) = -state2(bcy,2);
    state2(bcy,4) = -state2(bcy,4);
    % Ensure the electrons bounce back up if going below the low Y limit
  
    ra = rand(pop_tot, 1) < ps;
    scattersize = size(state2(ra,3:4));
    distvels = zeros(scattersize(1),1) + (randn(scattersize(1),1).*vth);
    newvels = ones(scattersize);
    
    for a = 1:scattersize(1)-1
        angle = rand*2*pi;
        vel = randn*vth;
        newvels(a, :) = [vel*cos(angle) vel*sin(angle)];
    end
 
    state2(ra,3:4) = newvels;
    % Check to see if the electrons will scatter based around the
    % probability calculated
    % If they do scatter, the velocity and direction will be changed to a
    % random value within the normal distribution around vth
    
    mfps(:) = mfps(:) + (ts * (sqrt(state2(:,3).^2 + state2(:,4).^2)));
    mfps(ra) = 0;
    meanfp = sum(mfps)/pop_tot;
    % The measured mean free path is found by calculating the distance
    % between each scatter for all electrons
    % The measured mean free path is 3.03e-8m or 30.3nm
    
    tbc(:) = tbc(:) + ts;
    tbc(ra) = 0;
    meantbc = sum(tbc)/pop_tot;
    % The measured time between collisions is found by tracking the time
    % between scatters for all electrons then taking the average.
    % The measured time between collision is 0.201e-12s or 0.201ps
    
    temps2(i) = (sum(state2(:,3).^2) + sum(state2(:,4).^2)) * mn/k/2/pop_tot;
    avgtemp2 = sum(temps2(1:i,1))/i;
    avgtemps2(i) = avgtemp2;
    % Track the temperature using the velocity of every electron at every
    % point
    
    for j = 1:pop_vis
        traj2(i, (2*j):(2*j+1)) = state2(j, 1:2);
    end
    % Track the trajectory of a small number of electrons by storing the x
    % and y position for each iteration
    
    % The animation does not need to be updated at every iteration
    % So we update it every 5 iterations to use less memory
    if animate2 && mod(i,5) == 0
        figure(2)
        pbaspect([2,1,1]);
        subplot(3,1,1);
        hold off;
        plot(state2(1:pop_vis,1)./1e-9, state2(1:pop_vis,2)./1e-9, 'o');
        axis([0 W/1e-9 0 H/1e-9]);
        title(sprintf('Trajectories for %d of %d Electrons with Normally Distributed Velocites (P.2)', pop_vis, pop_tot));
        xlabel('X (nm)');
        ylabel('Y (nm)');
        hold on;
        for j=1:pop_vis
            plot(traj2(:,j*2)./1e-9, traj2(:,j*2+1)./1e-9, '.');
        end
        
        if i > 1
            subplot(3,1,2);
            hold off;
            plot(ts*(0:i-1), temps2(1:i));
            hold on
            plot(ts*(0:i-1), avgtemps2(1:i));
            axis([0 ts*iter min(temps2)*0.98 max(temps2)*1.02]);
            title(sprintf('Temperature of the Semi-Conductor (avg = %f)', avgtemp2));
            xlabel('Time (s)');
            ylabel('Temperature (K)');
        end
        pause(0.05)
    end
end

% Now we need to display the trajectory after the iterations have completed
figure(2);
pbaspect([2,1,1]);
subplot(3,1,1);
hold off;
plot(state2(1:pop_vis,1)./1e-9, state2(1:pop_vis,2)./1e-9, 'o');
axis([0 W/1e-9 0 H/1e-9]);
title(sprintf('Trajectories for %d of %d Electrons with Normally Distributed Velocites (P.2)', pop_vis, pop_tot));
xlabel('X (nm)');
ylabel('Y (nm)');
hold on;
for i=1:pop_vis
    plot(traj2(:,i*2)./1e-9, traj2(:,i*2+1)./1e-9, '.');
end

% If the animation variable = 0, we need to simply plot the results
if(~animate2)
    subplot(3,1,2);
    hold off;
    plot(ts*(0:i-1), temps2(1:i));
    hold on;
    plot(ts*(0:i-1), avgtemps2(1:i));
    axis([0 ts*iter min(temps2)*0.98 max(temps2)*1.02]);
    title(sprintf('Temperature of the Semi-Conductor (avg = %f)', avgtemp2));
    xlabel('Time (s)');
    ylabel('Temperature (K)');
end



% to do:
% need to measure actual mean free path and mean time between collisions
% this will verify the model

%% Part 3: Enhancements

%%
% In order to track the electrons, the following arrays will be used
% The arrays will store the positions, velocities, and temperatures of the
% elctrons
% note that these are made the same way as in part 1 and part 2
state3 = zeros(pop_tot, 4);

% The rows of state represent each electron
% The columns represent the position and velocity in each direction as shown
% [x y vx vy]

% traj3 = zeros(iter, pop_vis*2);
traj3 = zeros(pop_tot, pop_vis*2);
% The trajectory of the electrons we want to plot will be stored here
% The population total is used here instead of the iteration number to
% ensure the injection gives the same number of electrons

% temps3 = zeros(iter,1);
% avgtemps3 = zeros(iter,1);
temps3 = zeros(pop_tot,1);
avgtemps3 = zeros(pop_tot,1);

initvels = zeros(pop_tot,1);

% animate3 = 1;               % set to 1 to see each iteration 
animate3 = 0;               % set to 0 to only see the final product

%%
% The top and bottom boundaries are made to be able to be specular or
% diffusive
top_spec = 1;
bot_spec = 0;

%%
% Boxes are defined to be added in by their boundaries
% The boxes are also able to be specular opr diffusive
% The boxes are formed by filling the following: [left_x right_x bottom_y
% top_y]
boxes = 1e-9 .* [80 120 0 40; 80 120 60 100];
b_spec = [1 0];

%%
% A circle is added to the right of the bottleneck
% The circle can be made specular or diffusive
% The circle is formed by filling the following: [center_xpos center_ypos radius]
circ = 1e-9 .* [150 50 10];
c_spec = 1;
theta = linspace(0,2*pi);
xc = circ(3)*cos(theta) + circ(1);
yc = circ(3)*sin(theta) + circ(2);
% To plot the circle, the angle above is caluclated as well as the top and
% bottom portions through the sin and cos functions

%% 
% Start by generating the initial eletrons with a normally distributed
% speed averaging around vth
% for i = 1:pop_tot
%     angle = rand*2*pi;
%     vel = randn*vth;
%     initvels(i) = vel;
%     state3(i,:) = [W*rand H*rand vel*cos(angle) vel*sin(angle)];
%     
% %     We need to make sure no particles appear in the boxes
%     while(inside(state3(i,1:2), boxes))
%         state3(i,1:2) = [W*rand H*rand];
%     end
% end
% This is not needed when injecting the electrons as we are starting with
% no electrons in the area


%%
% The third simulation gets run
% for i = 1:iter
for i = 1:pop_tot
    angle = rand*2*pi;
    vel = randn*vth;
    initvels(i) = vel;
    state3(i,:) = [0 ((H*0.6 - H*0.4)*rand)+(H*0.4) abs(vel*cos(angle)) vel*sin(angle)];
    
% %     We need to make sure no particles appear in the boxes
%     while(inside(state3(i,1:2), boxes))
%         state3(i,1:2) = [W*rand H*rand];
%     end

% %     We need to make sure no particles appear in the circle
%     while(incircle(state3(i,1:2), circ))
%         state3(i,1:2) = [W*rand H*rand];
%     end
% The above two are not required for checking because the electrons are
% being injected from the left. They will always begin outside the shapes.
     
    state3(:,1:2) = state3(:,1:2) + ts .* state3(:,3:4);
    % update the state of each electron using the speed
    
%     % We need to ensure the boundary conditions are checked
    bcx = state3(:,1) > W;
%     state3(bcx,1) = state3(bcx,1) - W;
%     % Ensure the electron is transported from the right side to the left if
%     % travelling past the right X limit
    state3(bcx,1) = 0;
    state3(bcx,2) = ((H*0.6 - H*0.4)*rand)+(H*0.4);
    state3(bcx,3) = abs(randn*vth*cos(rand*2*pi));
    state3(bcx,4) = randn*vth*sin(rand*2*pi);
    % The above checks to see if an electron has escapes to the left or the
    % right. If it has, it is reset to the initial injection location and
    % given a new speed. This ensures that there is no lose of electrons
    % while maintaining the distribution.

    
    bcx = state3(:,1) < 0;
%     state3(bcx,1) = state3(bcx,1) + W;
%     % Ensure the electron is transported from the left side to the right if
%     % travelling past the left X limit
    state3(bcx,1) = 0;
    state3(bcx,2) = ((H*0.6 - H*0.4)*rand)+(H*0.4);
    state3(bcx,3) = abs(randn*vth*cos(rand*2*pi));
    state3(bcx,4) = randn*vth*sin(rand*2*pi);

    
    bcy = state3(:,2) > H;
    
    % Change the reflection based on if the boundary is specular or
    % diffusive
    if(top_spec)    % specular
        state3(bcy,2) = 2*H - state3(bcy,2);
        state3(bcy,4) = -state3(bcy,4);
        % Ensure the electrons bounce back down if going above high the Y limit
    else    % diffusive - The electrons will bounce off at a random angle
        state3(bcy,2) = H;
        newv = sqrt(state3(bcy,3).^2 + state3(bcy,4).^2);
        newangle = rand([sum(bcy),1])*2*pi;
        state(bcy,3) = newv.*cos(newangle);
        state(bcy,4) = newv.*sin(newangle);
    end
        
    bcy = state3(:,2) < 0;  
    if(bot_spec)    % specular
        state3(bcy,2) = -state3(bcy,2);
        state3(bcy,4) = -state3(bcy,4);
        % Ensure the electrons bounce back up if going below the low Y limit
    else    % diffusive - The electrons will bounce off at a random angle
        state3(bcy,2) = 0;
        newv = sqrt(state3(bcy,3).^2 + state3(bcy,4).^2);
        newangle = rand([sum(bcy),1])*2*pi;
        state(bcy,3) = newv.*cos(newangle);
        state(bcy,4) = abs(newv.*sin(newangle));
    end
    
    %%
    % Electrons cannot be in the boxes, so we look for any that try to
    % enter and reflect them
    for j = 1:pop_tot
        bn = inside(state3(j,1:2), boxes);
        while(bn ~= 0)
            % Start by checking the side an electron has attempted to enter;
            if(state3(j,3) > 0)
                xd = state(j,1) - boxes(bn,1);
                newx = boxes(bn,1);
            else
                xd = boxes(bn,2) - state3(j,1);
                newx = boxes(bn,2);
            end

            if(state3(j,4) > 0)
                yd = state3(j,2) - boxes(bn, 3);
                newy = boxes(bn, 3);
            else
                yd = boxes(bn,4) - state3(j,2);
                newy = boxes(bn,4);
            end
            
            if(xd < yd)
                state3(j,1) = newx;
                if(~b_spec(bn))     % boxes are diffusive
                    s = -sign(state3(j,3));
                    newv = sqrt(state3(j,3).^2 + state3(j,4).^2);
                    newangle = rand()*2*pi;
                    state3(j,3) = s.*abs(newv.*cos(newangle));
                    state3(j,4) = newv.*sin(newangle);
                else    % boxes are specular
                    state3(j,3) = -state3(j,3);
                end
            else
                state3(j,2) = newy;
                if(~b_spec(bn))     % boxes are diffusive
                    s = -sign(state3(j,4));
                    newv = sqrt(state3(j,3).^2 + state3(j,4).^2);
                    newangle = rand()*2*pi;
                    state3(j,3) = newv.*cos(newangle);
                    state3(j,4) = s.*abs(newv.*sin(newangle));
                else    % boxes are specular
                    state3(j,4) = -state3(j,4);
                end
            end
            
            bn = inside(state3(j,1:2), boxes);
        end
    end
    
    %%
    % Electrons cannot be in the circle, so we look for any that try to
    % enter and reflect them
    for j = 1:pop_tot
       ic = incirc(state3(j,1:2), circ);
       while(ic ~= 0)
           if(c_spec)   % Circle is specular

                nor = atan2(state3(j,2)-circ(2),state3(j,1)-circ(1));
                
                vpart = [state3(j,3) state3(j,4)];
                vn = norm(vpart);
                
                circlecenterv = [state3(j,1)-circ(1) state3(j,2)-circ(2)];
                ccn = norm(circlecenterv);
                
                incangle = acos(dot(-vpart,circlecenterv)/(vn*ccn));
                
                new_angle = nor - incangle;
                
%                 incangle = atan2(state3(j,4),state3(j,3));
% 
%                 dangle = incangle - norm;
%                 new_angle = norm - dangle;

                v = sqrt((state3(j,3))^2 + (state3(j,4))^2);
                
                vx = cos(new_angle)*v;
                vy = sin(new_angle)*v;
                
                state3(j,3) = vx;
                state3(j,4) = vy;
                state3(j,1) = state3(j,1) + ts*state3(j,3);
                state3(j,2) = state3(j,2) + ts*state3(j,4);

%                incang = acos((circ(1)+state3(j,1))/circ(3));
%                v = sqrt((state3(j,3))^2 + (state3(j,4))^2);
%                theta = acos(state3(j,3)/v);
%                state3(j,3) = v*cos(theta + 2*incang);
%                state3(j,4) = v*sin(theta + 2*incang);
%                if theta > 0 && theta < (pi/4)
%                     if state3(j,2) > circ(2)
%                         state3(j,3) = v*cos(theta + 2*incang);
%                         state3(j,4) = v*sin(theta + 2*incang);
%                     else
%                         state3(j,3) = v*cos(theta + 2*incang);
%                         state3(j,4) = v*sin(theta + 2*incang);
%                     end
%                elseif theta > (pi/4) && theta < (pi/2)
%                    
%                elseif theta > (pi/2) && theta < (3*pi/4)
%                    
%                elseif theta > (3*pi/4) && theta < pi
%                    
%                elseif theta > pi && theta < (5*pi/4)
%                    
%                elseif theta > (5*pi/4) && theta < (3*pi/2)
%                    
%                elseif theta > (3*pi/2) && theta < (7*pi/4)
%                    
%                elseif theta > (7*pi/4) && theta < 2*pi
%                                      
%                end
           else         % Circle is diffusive
               % This code will be implemented in a further iteration.
               % There was not enough time to complete it before the due
               % date.
           end
           ic = incirc(state3(j,1:2), circ);
       end
        
    end
    
    %%
    % Check to see if electrons will scatter
    ra = rand(pop_tot, 1) < ps;
    scattersize = size(state3(ra,3:4));
    distvels = zeros(scattersize(1),1) + (randn(scattersize(1),1).*vth);
    newvels = ones(scattersize);
    
    for a = 1:scattersize(1)-1
        angle = rand*2*pi;
        vel = randn*vth;
        newvels(a, :) = [vel*cos(angle) vel*sin(angle)];
    end
 
    state3(ra,3:4) = newvels;
    % Check to see if the electrons will scatter based around the
    % probability calculated
    % If they do scatter, the velocity and direction will be changed to a
    % random value within the normal distribution around vth
        
    %%
    % The temperature needs to be recorded
    temps3(i) = (sum(state3(:,3).^2) + sum(state3(:,4).^2)) * mn/k/2/pop_tot;
    avgtemp3 = sum(temps3(1:i,1))/i;
    avgtemps3(i) = avgtemp3;
    % Track the temperature using the velocity of every electron at every
    % point
    
    %%
    for j = 1:pop_vis
        traj3(i, (2*j):(2*j+1)) = state3(j, 1:2);
    end
    % Track the trajectory of a small number of electrons by storing the x
    % and y position for each iteration
    
    %%
    % Only update the animation every 5 changes to reduce the memory use
    if animate3 && mod(i,5) == 0
        figure(3);
        pbaspect([2,1,1]);
%         subplot(3,1,1);
        hold off;
        plot(state3(1:pop_vis,1)./1e-9, state3(1:pop_vis,2)./1e-9, 'o');
        hold on;
        
        % The boxes need to be plotted as well
        for j = 1:size(boxes,1)
            plot([boxes(j,1) boxes(j,1) boxes(j,2) boxes(j,2) boxes(j,1)]./1e-9,...
                [boxes(j,3) boxes(j,4) boxes(j,4) boxes(j,3) boxes(j,3)]./1e-9, 'k-');
        end
        hold on;
                
        % The circle needs to be plotted as well
        plot(xc/1e-9,yc/1e-9);
        hold on;
        
        axis([0 W/1e-9 0 H/1e-9]);
        title(sprintf('Trajectories for %d of %d Electrons with Normally Distributed Velocites (P.3)', pop_vis, pop_tot));
        xlabel('X (nm)');
        ylabel('Y (nm)');
        hold on;
        for j=1:pop_vis
            plot(traj3(:,j*2)./1e-9, traj3(:,j*2+1)./1e-9, '.');
        end
        
%         if i > 1
%             subplot(3,1,2);
%             hold off;
%             plot(ts*(0:i-1), temps3(1:i));
%             hold on
%             plot(ts*(0:i-1), avgtemps3(1:i));
%             axis([0 ts*iter min(temps3)*0.98 max(temps3)*1.02]);
%             title(sprintf('Temperature of the Semi-Conductor (avg = %f)', avgtemp3));
%             xlabel('Time (s)');
%             ylabel('Temperature (K)');
%         end
% The subplot is not needed as the temperature is being tracked through the
% temperature map in figure 5
        
        pause(0.05);
    end
end

%%        
% The plots need to be shown after the animation is complete
figure(3);
pbaspect([2,1,1]);
% subplot(3,1,1);
hold off;
plot(state3(1:pop_vis,1)./1e-9, state3(1:pop_vis,2)./1e-9, 'o');
hold on;

% The boxes need to be plotted as well
for j = 1:size(boxes,1)
    plot([boxes(j,1) boxes(j,1) boxes(j,2) boxes(j,2) boxes(j,1)]./1e-9,...
        [boxes(j,3) boxes(j,4) boxes(j,4) boxes(j,3) boxes(j,3)]./1e-9, 'k-');
end

% The circle needs to be plotted as well
plot(xc/1e-9,yc/1e-9);
hold on;

axis([0 W/1e-9 0 H/1e-9]);
title(sprintf('Trajectories for %d of %d Electrons with Normally Distributed Velocites (P.3)', pop_vis, pop_tot));
xlabel('X (nm)');
ylabel('Y (nm)');
hold on;
for j=1:pop_vis
    plot(traj3(:,j*2)./1e-9, traj3(:,j*2+1)./1e-9, '.');
end

% if i > 1
%     subplot(3,1,2);
%     hold off;
%     plot(ts*(0:i-1), temps3(1:i));
%     hold on
%     plot(ts*(0:i-1), avgtemps3(1:i));
%     axis([0 ts*iter min(temps3)*0.98 max(temps3)*1.02]);
%     title(sprintf('Temperature of the Semi-Conductor (avg = %f)', avgtemp3));
%     xlabel('Time (s)');
%     ylabel('Temperature (K)');
% end
        
%% 
% An electron density map is created for the bottlenecked simulation
dense = hist3(state3(:,1:2),[200 1000])';

% The density map needs to be smoothed out a bit
N = 20;
sig = 3;
[x y] = meshgrid(round(-N/2):round(N/2), round(-N/2):round(N/2));
g = exp(-x.^2/(2*sig^2) - y.^2/(2*sig^2));
g = g./sum(g(:));
% subplot(3,1,2);
figure(4);
imagesc(conv2(dense, g, 'same'));
set(gca, 'YDir', 'normal');
title('Electron Density Map (Pt. 3)');
xlabel('x (nm)');
ylabel('y (nm)');

%%
% Similarily to the density map, a temperature map is created
% This map is created by putting the electron velocities into areas much
% smaller than the full space called bins.
x_temp_sum = zeros(ceil(W/1e-9), ceil(H/1e-9));
y_temp_sum = zeros(ceil(W/1e-9), ceil(H/1e-9));
num_temp = zeros(ceil(W/1e-9), ceil(H/1e-9));

% Start by observing the velocities of all the electrons
for i = 1:pop_tot
    % We now need to put the electrons in their bins based on location
    x = floor(state3(i,1)/1e-9);
    y = floor(state3(i,2)/1e-9);
    
    if(x == 0)
        x = 1;
    end
    if(y == 0)
        y = 1;
    end
    
    % The velocities are then added to the total count for each bin
    x_temp_sum(x,y) = x_temp_sum(x,y) + state3(i,3)^2;
    y_temp_sum(x,y) = y_temp_sum(x,y) + state3(i,4)^2;
    num_temp(x,y) = num_temp(x,y) + 1;
end

% Using the sum of the velocities, the temperature of each bin can be
% calculated
temp = (x_temp_sum + y_temp_sum).*mn./k./2./num_temp;
temp(isnan(temp)) = 0;
temp = temp';

% The map needs some smoothing out
N = 20;
sig = 3;
[x y] = meshgrid(round(-N/2):round(N/2), round(-N/2):round(N/2));
g = exp(-x.^2/(2*sig^2) - y.^2/(2*sig^2));
g = g./sum(g(:));
% subplot(3,1,3);
figure(5);
imagesc(conv2(temp, g, 'same'));
set(gca, 'YDir', 'normal');
title('Temperature Map (Pt. 3)');
xlabel('x (nm)');
ylabel('y (nm)');



