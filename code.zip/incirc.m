function ic = incirc(pos,circ)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
    ic = 0;
    if (pos(1)-circ(1))^2 + (pos(2)-circ(2))^2 < (circ(3))^2
        ic = 1;
    end
end

